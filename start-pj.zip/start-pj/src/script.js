document.querySelector("button").addEventListener("click", function() {
  alert("Button Clicked!");
});
